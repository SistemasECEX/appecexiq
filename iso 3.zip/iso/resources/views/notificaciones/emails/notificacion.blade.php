<html>
<body>

<h3>Notificación de sistema ISO/OEA/CTPAC</h3>

<p><strong>Usted tiene la siguiente notificación:</strong></p>
<p><strong>Asunto: </strong> {{ $notificacion->asunto }}</p>
<p><strong>Fecha de expiración: </strong> {{ $notificacion->fecha_de_expiracion }}</p>
<br>
<p>{{ $notificacion->descripcion }}</p>
    
    
</body>
</html>