<html>
<body>

<h3>Notificación de sistema ISO/OEA/CTPAC</h3>

<p><strong>Usted tiene la siguiente notificación:</strong></p>
<p><strong>Asunto: </strong> <?php echo e($notificacion->asunto); ?></p>
<p><strong>Fecha de expiración: </strong> <?php echo e($notificacion->fecha_de_expiracion); ?></p>
<br>
<p><?php echo e($notificacion->descripcion); ?></p>
    
    
</body>
</html><?php /**PATH /Users/juanjacobo/Documents/GitHub/ISO/iso/resources/views/notificaciones/emails/notificacion.blade.php ENDPATH**/ ?>