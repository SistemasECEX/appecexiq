<?php

namespace App\Http\Controllers;

use App\Models\formatosllenos_user;
use App\Http\Requests\Store_formatosllenos_userRequest;
use App\Http\Requests\Update_formatosllenos_userRequest;

class FormatosllenosUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Storecreate_formatosllenos_userRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Storecreate_formatosllenos_userRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\create_formatosllenos_user  $create_formatosllenos_user
     * @return \Illuminate\Http\Response
     */
    public function show(create_formatosllenos_user $create_formatosllenos_user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\create_formatosllenos_user  $create_formatosllenos_user
     * @return \Illuminate\Http\Response
     */
    public function edit(create_formatosllenos_user $create_formatosllenos_user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Updatecreate_formatosllenos_userRequest  $request
     * @param  \App\Models\create_formatosllenos_user  $create_formatosllenos_user
     * @return \Illuminate\Http\Response
     */
    public function update(Updatecreate_formatosllenos_userRequest $request, create_formatosllenos_user $create_formatosllenos_user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\create_formatosllenos_user  $create_formatosllenos_user
     * @return \Illuminate\Http\Response
     */
    public function destroy(create_formatosllenos_user $create_formatosllenos_user)
    {
        //
    }
}
