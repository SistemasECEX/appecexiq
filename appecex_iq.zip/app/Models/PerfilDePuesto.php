<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PerfilDePuesto extends Model
{
    use HasFactory;
    protected $table = 'perfiles_de_puesto';
}
