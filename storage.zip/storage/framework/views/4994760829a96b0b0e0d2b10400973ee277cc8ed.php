<?php $__env->startSection('headers'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Page Content -->

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">





                <h5 style="text-align:center"><strong>Bienvenido al Sistema de Control de Documentos</strong> ISO - CTPAT - OEA</h5>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>

function myFunction()
{
    showModal("Titulo","Mensage");
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SistemasECEX\Documents\GitHub\appecex_iq\resources\views/inicio.blade.php ENDPATH**/ ?>